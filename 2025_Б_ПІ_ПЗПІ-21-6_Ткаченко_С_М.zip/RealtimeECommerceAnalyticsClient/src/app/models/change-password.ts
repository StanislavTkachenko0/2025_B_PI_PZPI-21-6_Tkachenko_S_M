export interface ChangePassword {
  newPassword: string;
}
