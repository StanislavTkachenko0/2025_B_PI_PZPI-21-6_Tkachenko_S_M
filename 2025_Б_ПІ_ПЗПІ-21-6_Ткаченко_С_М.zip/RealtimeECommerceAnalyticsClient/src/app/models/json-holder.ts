export interface JsonHolder {
  json: string;
  languageCode: string;
  version: number;
}
