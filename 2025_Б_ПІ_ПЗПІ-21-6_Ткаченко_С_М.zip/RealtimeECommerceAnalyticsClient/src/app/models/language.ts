export interface Language {
  languageName: string;
  languageCode: string;
  version: number;
}

export interface AddLanguage {
  languageName: string;
  languageCode: string;
}

