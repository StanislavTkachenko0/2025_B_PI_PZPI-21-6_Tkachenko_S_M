export enum SourceData {
  FakeStore= 'FakeStore',
  DummyJSON = 'DummyJSON',
  OpenLibrary = 'OpenLibrary',
  OpenFoodFacts = 'OpenFoodFacts',
  CoinGecko = 'CoinGecko',
}
