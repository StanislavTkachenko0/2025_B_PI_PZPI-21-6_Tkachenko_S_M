export interface RegisterModel {
  email: string;
  password: string;
  confirmPassword?: string;
  role: string;
}
