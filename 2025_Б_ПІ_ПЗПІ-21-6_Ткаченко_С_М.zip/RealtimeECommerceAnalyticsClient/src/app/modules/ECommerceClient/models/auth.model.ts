export interface AuthModel {
  email: string;
  password: string;
  token?: string;
}
