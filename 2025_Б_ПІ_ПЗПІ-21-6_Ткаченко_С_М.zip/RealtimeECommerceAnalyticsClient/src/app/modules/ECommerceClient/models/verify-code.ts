export interface VerifyCode {
  code: string;
  email: string;
}
