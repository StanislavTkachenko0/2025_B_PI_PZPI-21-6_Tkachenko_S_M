import { Component } from '@angular/core';

@Component({
  selector: 'app-client-busy',
  standalone: false,
  templateUrl: './client-busy.component.html'
})
export class ClientBusyComponent {

}
