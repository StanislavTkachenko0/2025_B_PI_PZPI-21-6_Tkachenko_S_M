import { Component } from '@angular/core';

@Component({
  selector: 'app-main-admin-page',
  standalone: false,
  templateUrl: './main-admin-page.component.html'
})
export class MainAdminPageComponent {

}
