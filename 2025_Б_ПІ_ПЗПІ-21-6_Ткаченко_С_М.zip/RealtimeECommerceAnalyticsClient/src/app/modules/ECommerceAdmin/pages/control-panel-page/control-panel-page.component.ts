import {Component, OnDestroy, OnInit} from '@angular/core';
import {FileUploadHandlerEvent} from 'primeng/fileupload';

@Component({
  selector: 'app-control-panel-page',
  standalone: false,
  templateUrl: './control-panel-page.component.html'
})
export class ControlPanelPageComponent implements OnInit, OnDestroy {

  constructor() {
  }

  ngOnDestroy() {

  }

  ngOnInit() {
  }
}
