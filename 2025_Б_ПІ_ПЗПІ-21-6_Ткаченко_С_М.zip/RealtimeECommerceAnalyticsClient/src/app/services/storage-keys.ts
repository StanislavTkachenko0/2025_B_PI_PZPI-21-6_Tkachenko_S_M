export class StorageKeys {

  public static Language = 'lang';
  public static VerifyEmail = 'verify_email';
  public static SentCode = 'sent_code';
}
