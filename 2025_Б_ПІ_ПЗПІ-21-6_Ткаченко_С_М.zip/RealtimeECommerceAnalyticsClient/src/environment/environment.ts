export const environment = {
  production: false,
  apiUrl: 'https://localhost:44319',
  tokenWhiteListedDomains: ['localhost:7143']
};
