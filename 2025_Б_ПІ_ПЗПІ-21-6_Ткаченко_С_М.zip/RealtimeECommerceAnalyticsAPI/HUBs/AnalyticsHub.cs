﻿using Microsoft.AspNetCore.SignalR;

namespace RealtimeECommerceAnalytics.HUBs
{
    public class AnalyticsHub : Hub
    {
    }
}
