﻿namespace RealtimeECommerceAnalytics.Enums
{
    public enum DataSource
    {
        FakeStore,
        DummyJSON,
        OpenLibrary,
        OpenFoodFacts,
        CoinGecko
    }
}
