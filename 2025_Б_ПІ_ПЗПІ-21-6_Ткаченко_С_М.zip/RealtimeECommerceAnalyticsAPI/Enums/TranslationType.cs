﻿namespace RealtimeECommerceAnalytics.Enums
{
    public enum TranslationType
    {
        LanguagesList,
        Language,
        LanguageModel
    }
}
