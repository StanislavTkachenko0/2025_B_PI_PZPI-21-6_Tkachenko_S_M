﻿namespace RealtimeECommerceAnalytics.Models
{
    public class Marketplace
    {
    }
}
