﻿namespace RealtimeECommerceAnalytics.Models.Auth
{
    public class RegisterDto : AuthModel
    {
        public string Role { get; set; } = "User";
    }
}
