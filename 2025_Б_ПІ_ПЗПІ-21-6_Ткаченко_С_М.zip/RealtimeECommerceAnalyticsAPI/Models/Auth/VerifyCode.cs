﻿namespace RealtimeECommerceAnalytics.Models.Auth
{
    public class VerifyCode
    {
        public string Email { get; set; }
        public string Code { get; set; }
    }
}
