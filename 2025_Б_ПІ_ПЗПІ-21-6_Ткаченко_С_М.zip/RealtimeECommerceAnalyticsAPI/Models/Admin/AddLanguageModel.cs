﻿namespace RealtimeECommerceAnalytics.Models.Admin
{
    public class AddLanguageModel
    {
        public string LanguageName { get; set; }
        public string LanguageCode { get; set; }
    }
}
