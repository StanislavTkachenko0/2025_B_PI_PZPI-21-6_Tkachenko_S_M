﻿namespace RealtimeECommerceAnalytics.Models
{
    public class ChangePassword
    {
        public string NewPassword { get; set; }
    }
}
